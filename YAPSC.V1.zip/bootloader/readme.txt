ENG:
Bootloader program installation (compatible with windows only)

Execute IBLInstaller.exe and read the instructions.
Note the file path where you have installed the bootlodaer program (by default C:\Program Files\Ingenia\dsPICbootloader)

copy the file ibl_dspiclist.xml in this folder (C:\Program Files\Ingenia\dsPICbootloader\ibl_dspiclist.xml) and choose to replace the original file.
THIS IS NECESSARY STEP to update your YAPSC board!





FRA:
Installation du programme de bootloader:

ex�cutez "IBLInstaller.exe" et suivez les instructions.
Notez bien le chemin dans lequel vous avec install� l'application si vous n'avez pas choisi la valeur par d�faut!

il faut maintenant copier "ibl_dspiclist.xml" dans le r�pertoire racine du bootloader (par d�faut "C:\Program Files\Ingenia\dsPICbootloader"), en remplacant le fichier d'origine.
CETTE ETAPE EST NECESSAIRE pour pouvoir mettre � jour votre carte YAPSC!