The gerber files default name from kicad has non classic .pho file extension instead of .GBO,.GTL... gerber file extension, so the bat command file "rename_gerbers.bat" takes car of that.
When you update the PCB in KiCAD, export it to gerber (trace menu), delete any .GTL, .GTO etc. files existing and then run "rename_gerbers.bat".
Now the gerber files have the extensions PCB manufacturers are expecting. Just include the gerber files and the dill file (.drl) should be enough for them to produce a complete PCB.
Postscript files are also included for Linux-users who want to print them directly

### Gerber files: ###
yapsc-Composant.GTL
yapsc-Cuivre.GBL
yapsc-Masque_Cmp.GTS
yapsc-Masque_Cu.GBS
yapsc-Serigr_Cmp.GTO
yapsc-Serigr_Cu.GBO

#### Drill file: ####
yapsc.drl

# Postscript files: #
yapsc-Composant.ps
yapsc-Cuivre.ps
yapsc-Masque_Cmp.ps
yapsc-Masque_Cu.ps
yapsc-Serigr_Cmp.ps
yapsc-Serigr_Cu.ps