This RS232 prog dongle need fixing, espetially on the optocouplers wich are not really well suited. I recommend using 6N136 or 6N137 instead of H11A1, 4Nxx etc.

I don't recomment it's use anymore.
Use the USB version instead, which is proved to be reliable event at 115Kbps